package de.bht.fb6.cg1.s778455.colorconverter;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * This class represents the ColorConverter. An application to convert colors
 * between differen color models.
 * 
 * @author Stephan Rehfeld <rehfeld (-at-) beuth-hochschule.de>
 */
public class ColorConverterJFrame extends JFrame implements ChangeListener,
		ActionListener {

	/**
	 * Internal values to decide which component was last changed.
	 */
	private static final int RGBMODE = 0;
	/**
	 * Internal values to decide which component was last changed.
	 */
	private static final int YUVMODE = 1;
	/**
	 * Internal values to decide which component was last changed.
	 */
	private static final int CMYMODE = 2;
	/**
	 * Height of the LogTextArea.
	 */
	private static final int LOGROWS = 50;
	/**
	 * Width of the LogTextArea.
	 */
	private static final int LOGCOLS = 50;
	/**
	 * Show Log - Button Text.
	 */
	private static final String SHOWBUTTONTEXT = "Show Log";

	/**
	 * The main method.
	 * 
	 * @param args
	 *            Console parameters. This main method does not consume any
	 *            parameters.
	 */
	public static void main( final String args[] ) {
		java.awt.EventQueue.invokeLater(new Runnable( ) {

			@Override
			public void run() {
				new ColorConverterJFrame( ).setVisible(true );
			}

		} );
	}

	/**
	 * This attribute indicates that the program is currently updating the
	 * slider and should not react on value changes.
	 */
	private boolean update;

	/**
	 * This is the canvas that shows the current color.
	 */
	private Canvas colorCanvas;

	/**
	 * The current color.
	 */
	private Color currentColor;

	/**
	 * The panel that holds all controls for RGB color.
	 */
	private JPanel rgbPanel;

	/**
	 * The panel that holds all controls for YUV color.
	 */
	private JPanel yuvPanel;

	/**
	 * This slider controls the r component of RGB.
	 */
	private JSlider rSlider;

	/**
	 * This text field shows the current value of the r component of RGB.
	 */
	private JTextField rTextField;

	/**
	 * This slider controls the g component of RGB.
	 */
	private JSlider gSlider;

	/**
	 * This text field shows the current value of the g component of RGB.
	 */
	private JTextField gTextField;

	/**
	 * This slider controls the b component of RGB.
	 */
	private JSlider bSlider;

	/**
	 * This text field shows the current value of the b component of RGB.
	 */
	private JTextField bTextField;

	/**
	 * This slider controls the y component of YUV.
	 */
	private JSlider ySlider;

	/**
	 * This text field shows the current value of the y component of YUV.
	 */
	private JTextField yTextField;

	/**
	 * This slider controls the u component of YUV.
	 */
	private JSlider uSlider;

	/**
	 * This text field shows the current value of the u component of YUV.
	 */
	private JTextField uTextField;

	/**
	 * This slider controls the v component of YUV.
	 */
	private JSlider vSlider;

	/**
	 * This text field shows the current value of the v component of YUV.
	 */
	private JTextField vTextField;

	private JPanel cmyPanel;

	private JTextField cmyCTextField;

	private JSlider cmyCSlider;

	private JSlider cmyMSlider;

	private JSlider cmyYSlider;

	private JTextField cmyYTextField;

	private JTextField cmyMTextField;
	private JTextArea logField;
	private JPanel logFieldPanel;
	private JButton showLogButton;
	private JScrollPane logFieldPane;

	/**
	 * This constructor creates a new Frame of the ColorConverter with the size
	 * 640x480. It already close it self if requested and has the correct frame
	 * title.
	 */
	public ColorConverterJFrame() {
		super("Color Converter" );
		this.update = false;
		this.setSize(640, 480 );
		this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE );

		this.setLayout(new GridLayout(0, 1 ) );

		this.currentColor = Color.WHITE;

		this.createColorCanvas( );
		this.createRGBPanel( );
		this.createYUVPanel( );
		this.createCMYPanel( );

		// AddOn: ShowLog - Plugin
		this.createLogPanel( );

		this.pack( );

	}

	private void createLogPanel() {
		// this.add(Box.createRigidArea(new Dimension(1,0)));
		this.logFieldPanel = new JPanel( );
		logField = new JTextArea(LOGCOLS, LOGROWS );
		logFieldPane = new JScrollPane(logField );
		logFieldPane.setSize(new Dimension(LOGCOLS, LOGROWS ) );
		this.logFieldPanel.setLayout(new BoxLayout(logFieldPanel,
				BoxLayout.Y_AXIS ) );
		showLogButton = new JButton(SHOWBUTTONTEXT );
		this.logFieldPanel.add(showLogButton );
		showLogButton.addActionListener(this );
		showLogButton.setHorizontalAlignment(SwingConstants.CENTER );
		// Hide LogField
		this.logFieldPanel.add(logFieldPane );
		logField.setEditable(false );
		this.add(logFieldPanel );
	}

	/**
	 * This method creates the color canvas
	 */
	private void createColorCanvas() {
		this.colorCanvas = new Canvas( );
		this.colorCanvas.setBackground(this.currentColor );
		this.add(this.colorCanvas );

	}

	/**
	 * This method creates the panel for RGB
	 */
	private void createRGBPanel() {
		this.rgbPanel = new JPanel( );
		this.rgbPanel
				.setBorder(javax.swing.BorderFactory.createEtchedBorder( ) );
		this.add(this.rgbPanel );
		this.rgbPanel.setLayout(new GridLayout(3, 3 ) );

		final JLabel rLabel = new JLabel("R" );
		this.rgbPanel.add(rLabel );

		this.rSlider = new JSlider(0, 255, 255 );
		this.rgbPanel.add(this.rSlider );
		this.rSlider.addChangeListener(this );

		this.rTextField = new JTextField( );
		this.rgbPanel.add(this.rTextField );
		this.rTextField.setText("255" );
		this.rTextField.setEnabled(true );
		// ActionListener for TextField
		rTextField.addActionListener(this );

		final JLabel gLabel = new JLabel("G" );
		this.rgbPanel.add(gLabel );

		this.gSlider = new JSlider(0, 255, 255 );
		this.rgbPanel.add(this.gSlider );
		this.gSlider.addChangeListener(this );

		this.gTextField = new JTextField( );
		this.rgbPanel.add(this.gTextField );
		this.gTextField.setText("255" );
		this.gTextField.setEnabled(true );
		// ActionListener for TextField
		gTextField.addActionListener(this );

		final JLabel bLabel = new JLabel("B" );
		this.rgbPanel.add(bLabel );

		this.bSlider = new JSlider(0, 255, 255 );
		this.rgbPanel.add(this.bSlider );
		this.bSlider.addChangeListener(this );

		this.bTextField = new JTextField( );
		this.rgbPanel.add(this.bTextField );
		this.bTextField.setText("255" );
		this.bTextField.setEnabled(true );
		// ActionListener for TextField
		bTextField.addActionListener(this );
	}

	/**
	 * This method creates the panel for YUV
	 */
	private void createYUVPanel() {
		this.yuvPanel = new JPanel( );
		this.yuvPanel
				.setBorder(javax.swing.BorderFactory.createEtchedBorder( ) );
		this.add(this.yuvPanel );
		this.yuvPanel.setLayout(new GridLayout(3, 3 ) );

		final JLabel yLabel = new JLabel("Y" );
		this.yuvPanel.add(yLabel );

		this.ySlider = new JSlider(0, 255, 255 );
		this.yuvPanel.add(this.ySlider );
		this.ySlider.addChangeListener(this );

		this.yTextField = new JTextField( );
		this.yuvPanel.add(this.yTextField );
		this.yTextField.setText("255" );
		this.yTextField.setEnabled(true );
		// ActionListener for TextField
		yTextField.addActionListener(this );

		final JLabel uLabel = new JLabel("U" );
		this.yuvPanel.add(uLabel );

		this.uSlider = new JSlider(0, 222, 222 );
		this.yuvPanel.add(this.uSlider );
		this.uSlider.addChangeListener(this );

		this.uTextField = new JTextField( );
		this.yuvPanel.add(this.uTextField );
		this.uTextField.setText("" + YUV.UMAX );
		this.uTextField.setEnabled(true );
		// ActionListener for TextField
		uTextField.addActionListener(this );

		final JLabel vLabel = new JLabel("V" );
		this.yuvPanel.add(vLabel );

		this.vSlider = new JSlider(0, 314, 314 );
		this.yuvPanel.add(this.vSlider );
		this.vSlider.addChangeListener(this );

		this.vTextField = new JTextField( );
		this.yuvPanel.add(this.vTextField );
		this.vTextField.setText("" + YUV.VMAX );
		this.vTextField.setEnabled(true );
		// ActionListener for TextField
		vTextField.addActionListener(this );
	}

	/**
	 * creates the CMY panel
	 * 
	 * @author Sascha Feldmann
	 */
	public void createCMYPanel() {
		this.cmyPanel = new JPanel( );
		this.cmyPanel
				.setBorder(javax.swing.BorderFactory.createEtchedBorder( ) );
		this.add(this.cmyPanel );
		this.cmyPanel.setLayout(new GridLayout(3, 3 ) );

		final JLabel cmyCLabel = new JLabel("C" );
		this.cmyPanel.add(cmyCLabel );

		this.cmyCSlider = new JSlider(0, 255, 255 );
		this.cmyPanel.add(this.cmyCSlider );
		this.cmyCSlider.addChangeListener(this );

		this.cmyCTextField = new JTextField( );
		this.cmyPanel.add(this.cmyCTextField );
		this.cmyCTextField.setText("255" );
		this.cmyCTextField.setEnabled(true );
		// ActionListener for TextField
		cmyCTextField.addActionListener(this );

		final JLabel cmyMLabel = new JLabel("M" );
		this.cmyPanel.add(cmyMLabel );

		this.cmyMSlider = new JSlider(0, 255, 255 );
		this.cmyPanel.add(this.cmyMSlider );
		this.cmyMSlider.addChangeListener(this );

		this.cmyMTextField = new JTextField( );
		this.cmyPanel.add(this.cmyMTextField );
		this.cmyMTextField.setText("255" );
		this.cmyMTextField.setEnabled(true );
		// ActionListener for TextField
		cmyMTextField.addActionListener(this );

		final JLabel cmyYLabel = new JLabel("Y" );
		this.cmyPanel.add(cmyYLabel );

		this.cmyYSlider = new JSlider(0, 255, 255 );
		this.cmyPanel.add(this.cmyYSlider );
		this.cmyYSlider.addChangeListener(this );

		this.cmyYTextField = new JTextField( );
		this.cmyPanel.add(this.cmyYTextField );
		this.cmyYTextField.setText("255" );
		this.cmyYTextField.setEnabled(true );
		// ActionListener for TextField
		cmyYTextField.addActionListener(this );

	}

	@Override
	/**
	 * This method handles all slider-events.
	 * Change the ColorField and textual information.
	 */
	public void stateChanged( final ChangeEvent e ) {
		int colorspace = 0;

//		if ( !this.update ) {
			if ( e.getSource( ) == this.rSlider
					&& Integer.parseInt(this.rTextField.getText( ) ) != this.rSlider
							.getValue( ) ) {
				this.rTextField.setText("" + this.rSlider.getValue( ) );
				this.currentColor = new Color(this.rSlider.getValue( ),
						this.currentColor.getGreen( ),
						this.currentColor.getBlue( ) );
				colorspace = RGBMODE;
			} else if ( e.getSource( ) == this.gSlider
					&& Integer.parseInt(this.gTextField.getText( ) ) != this.gSlider
							.getValue( ) ) {
				this.gTextField.setText("" + this.gSlider.getValue( ) );
				this.currentColor = new Color(this.currentColor.getRed( ),
						this.gSlider.getValue( ), this.currentColor.getBlue( ) );
				colorspace = RGBMODE;
			} else if ( e.getSource( ) == this.bSlider
					&& Integer.parseInt(this.bTextField.getText( ) ) != this.bSlider
							.getValue( ) ) {
				this.bTextField.setText("" + this.bSlider.getValue( ) );
				this.currentColor = new Color(this.currentColor.getRed( ),
						this.currentColor.getGreen( ), this.bSlider.getValue( ) );
				colorspace = RGBMODE;
			} else if ( e.getSource( ) == this.ySlider
					&& Integer.parseInt(this.yTextField.getText( ) ) != this.ySlider
							.getValue( ) ) {
				this.yTextField.setText("" + this.ySlider.getValue( ) );
				colorspace = YUVMODE;
			} else if ( e.getSource( ) == this.uSlider
					&& Integer.parseInt(this.uTextField.getText( ) ) != this.uSlider
							.getValue( ) ) {
				this.uTextField.setText(""
						+ ( this.uSlider.getValue( ) - YUV.UMAX ) );
				colorspace = YUVMODE;
			} else if ( e.getSource( ) == this.vSlider
					&& Integer.parseInt(this.vTextField.getText( ) ) != this.vSlider
							.getValue( ) ) {
				this.vTextField.setText(""
						+ ( this.vSlider.getValue( ) - YUV.VMAX ) );
				colorspace = YUVMODE;
			} else if ( e.getSource( ) == this.cmyCSlider
					&& Integer.parseInt(this.cmyCTextField.getText( ) ) != this.cmyCSlider
							.getValue( ) ) {
				this.cmyCTextField.setText("" + this.cmyCSlider.getValue( ) );
				colorspace = CMYMODE;
			} else if ( e.getSource( ) == this.cmyMSlider
					&& Integer.parseInt(this.cmyMTextField.getText( ) ) != this.cmyMSlider
							.getValue( ) ) {
				this.cmyMTextField.setText("" + this.cmyMSlider.getValue( ) );
				colorspace = CMYMODE;
			} else if ( e.getSource( ) == this.cmyYSlider
					&& Integer.parseInt(this.cmyYTextField.getText( ) ) != this.cmyYSlider
							.getValue( ) ) {
				this.cmyYTextField.setText("" + this.cmyYSlider.getValue( ) );
				colorspace = CMYMODE;
			}

			this.colorCanvas.setBackground(this.currentColor );
			this.update(colorspace );
//		}

	}

	/**
	 * This method updates all other components if one component has changed.
	 * 
	 * @param currColorspace
	 *            - has to be one of the constants CMYMODE, RGBMODE, YUVMODE
	 *            values.
	 */
	private void update( final int currColorspace ) {

		if ( !this.update ) {
			// Update all others
			if ( currColorspace == CMYMODE ) {
				
				CMY cmy = new CMY(cmyCTextField.getText( ),
						cmyMTextField.getText( ), cmyYTextField.getText( ) );

				RGB rgb = cmy.returnRGB( );
				updateRGBPanel(rgb );
				// ShowLog-Addon
				logField.setText(logField.getText( ) + cmy );
				logField.setText(logField.getText( ) + "converted to \n" + rgb );
			} else if ( currColorspace == RGBMODE ) {
				RGB rgb = new RGB(rTextField.getText( ), gTextField.getText( ),
						bTextField.getText( ) );
				CMY cmy = rgb.returnCMY( );
				try {
					this.update = true;
					YUV yuv = rgb.returnYUV( );
					updateYUVPanel(yuv );
					yTextField.setBackground(new Color(255, 255, 255 ) );
					uTextField.setBackground(new Color(255, 255, 255 ) );
					vTextField.setBackground(new Color(255, 255, 255 ) );
					updateCMYPanel(cmy );
					// Show log
					logField.setText(logField.getText( ) + rgb );
					logField.setText(logField.getText( ) + "converted to \n"
							+ cmy );
					logField.setText(logField.getText( )
							+ "and converted to \n" + yuv );
					this.update = false;
				} catch ( IllegalArgumentException e ) {
					if ( e.toString( ).indexOf("for y" ) != -1 ) {
						// Luminance out of bounds
						yTextField.setBackground(new Color(255, 0, 0 ) );
					} else if ( e.toString( ).indexOf("for u" ) != -1 ) {
						// Luminance out of bounds
						yTextField.setBackground(new Color(255, 255, 255 ) );
						uTextField.setBackground(new Color(255, 0, 0 ) );
					} else if ( e.toString( ).indexOf("for v" ) != -1 ) {
						// Luminance out of bounds
						yTextField.setBackground(new Color(255, 255, 255 ) );
						uTextField.setBackground(new Color(255, 255, 255 ) );
						vTextField.setBackground(new Color(255, 0, 0 ) );
					}
					updateCMYPanel(cmy );
				}
			} else if ( currColorspace == YUVMODE ) {
				this.update = true;
				YUV yuv = new YUV(yTextField.getText( ), uTextField.getText( ),
						vTextField.getText( ) );
				try {
					RGB rgb = yuv.returnRGB( );
					rTextField.setBackground(new Color(255, 255, 255 ) );
					gTextField.setBackground(new Color(255, 255, 255 ) );
					bTextField.setBackground(new Color(255, 255, 255 ) );
					updateRGBPanel(rgb );

					logField.setText(logField.getText( ) + yuv );
					logField.setText(logField.getText( ) + "converted to \n"
							+ rgb );
				} catch ( IllegalArgumentException e ) {
					if ( e.toString( ).indexOf("for component red" ) != -1 ) {
						rTextField.setBackground(new Color(255, 0, 0 ) );
					} else if ( e.toString( ).indexOf("for component green" ) != -1 ) {
						rTextField.setBackground(new Color(255, 255, 255 ) );
						gTextField.setBackground(new Color(255, 0, 0 ) );
					} else if ( e.toString( ).indexOf("for component blue" ) != -1 ) {
						rTextField.setBackground(new Color(255, 255, 255 ) );
						gTextField.setBackground(new Color(255, 255, 255 ) );
						bTextField.setBackground(new Color(255, 0, 0 ) );
					}
				}
				finally {
					this.update = false;
				}
			}
		}
	}

	/**
	 * This method updates the YUV panel after an update of values.
	 * 
	 * @param yuv
	 *            - the YUV instance which contains the values to update.
	 */
	private void updateYUVPanel( final YUV yuv ) {
		ySlider.setValue(yuv.getY( ) );
		uSlider.setValue(yuv.getU( ) + YUV.UMAX );
		vSlider.setValue(yuv.getV( ) + YUV.VMAX );
	}

	/**
	 * This method updates the CMY panel after an update of values.
	 * 
	 * @param cmy
	 *            - the CMY instance which contains the values to update.
	 */
	private void updateCMYPanel( final CMY cmy ) {
		// TODO Auto-generated method stub
		cmyCSlider.setValue(cmy.getCyan( ) );
		cmyMSlider.setValue(cmy.getMagenta( ) );
		cmyYSlider.setValue(cmy.getYellow( ) );
	}

	/**
	 * Change the slider values of RGB components
	 * 
	 * @param rgb
	 *            - an rgb object
	 */
	private void updateRGBPanel( final RGB rgb ) {
		rSlider.setValue(rgb.getRed( ) );
		gSlider.setValue(rgb.getGreen( ) );
		bSlider.setValue(rgb.getBlue( ) );
	}

	@Override
	/**
	 * This method handles all "onClick"-events, such as inputs in text fields and clicks on buttons.
	 */
	public void actionPerformed( final ActionEvent e ) {
		if ( e.getSource( ) != showLogButton ) {
			int max = 0;
			int min = 0;
			JSlider aktSlider = null;
			if ( e.getSource( ) == rTextField ) {
				aktSlider = rSlider;
				min = RGB.MIN;
				max = RGB.MAX;
			} else if ( e.getSource( ) == gTextField ) {
				aktSlider = gSlider;
				min = RGB.MIN;
				max = RGB.MAX;
			} else if ( e.getSource( ) == bTextField ) {
				aktSlider = bSlider;
				min = RGB.MIN;
				max = RGB.MAX;
			} else if ( e.getSource( ) == yTextField ) {
				aktSlider = ySlider;
				min = YUV.YMIN;
				max = YUV.YMAX;
			} else if ( e.getSource( ) == uTextField ) {
				aktSlider = uSlider;
				min = YUV.UMIN;
				max = YUV.UMAX;
			} else if ( e.getSource( ) == vTextField ) {
				aktSlider = vSlider;
				min = YUV.UMIN;
				max = YUV.UMAX;
			} else if ( e.getSource( ) == cmyCTextField ) {
				aktSlider = cmyCSlider;
				min = CMY.MIN;
				max = CMY.MAX;
			} else if ( e.getSource( ) == cmyMTextField ) {
				aktSlider = cmyMSlider;
				min = CMY.MIN;
				max = CMY.MAX;
			} else if ( e.getSource( ) == cmyYTextField ) {
				aktSlider = cmyYSlider;
				min = CMY.MIN;
				max = CMY.MAX;
			}

			if ( aktSlider != null ) {
				int value = Integer.parseInt(( ( JTextField ) e.getSource( ) )
						.getText( ) );
				if ( value < min || value > max ) {
					showInfo("Please enter a value between " + min + " and "
							+ max );
					aktSlider.setValue(0 );
				} else {
					// Trick -> manipulating the textfield data so the action
					// event
					// condition works
					( ( JTextField ) e.getSource( ) )
							.setText("" + ( value - 1 ) );
					aktSlider.setValue(value );
				}
			}
		}
		// ShowLog-Event
		else {
			if ( logFieldPane.isVisible( ) ) {
				logFieldPane.setVisible(false );
			} else {
				logFieldPane.setVisible(true );
			}

		}
	}

	/**
	 * Show a System information window.
	 * 
	 * @param msg
	 *            - The String with the information.
	 */
	private void showInfo( final String msg ) {
		JOptionPane.showMessageDialog(this, msg, "Info",
				JOptionPane.INFORMATION_MESSAGE );

	}
}
