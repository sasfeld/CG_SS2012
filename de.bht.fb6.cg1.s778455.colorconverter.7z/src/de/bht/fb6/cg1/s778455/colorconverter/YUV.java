package de.bht.fb6.cg1.s778455.colorconverter;
/**
 * This class modelles the YUV colorspace.
 * @author Sascha Feldmann
 *
 */
public class YUV {
	/**
	 * minimum allowed value for the luminance Y.
	 */
	public static final int YMIN = 0;
	/**
	 * maxmimum allowed value for the luminance Y.
	 */
	public static final int YMAX = 255;
	/**
	 * minimum allowed value for chromances U.
	 * See the documentation for the calculation of this value.
	 */
	public static final int UMIN = -111;
	/**
	 * maximum allowed value for chromances U
	 * See the documentation for the calculation of this value.
	 */
	public static final int UMAX = 111;
	/**
	 * maximum allowed value for chromances V.
	 * See the documentation for the calculation of this value.
	 */
	public static final int VMIN = -157;
	/**
	 * maximum allowed value for chromances V.
	 * See the documentation for the calculation of this value.
	 */
	public static final int VMAX = 157;
	/**
	 * the luminance - a value between 0 and  255
	 */
	private final int y;
	/**
	 * cyan-red-balance - a value between -111 and 111
	 */
	private final int u;
	/**
	 * yellow-blue-balance - a value between -157 and 157
	 */
	private final int v;

	/**
	 * Create a new instance of the colorspace with uneditable values.
	 * @param y the luminance - a value between 0 and  255
	 * @param u cyan-red-balance - a value between -111 and 111
	 * @param v yellow-blue-balance - a value between -157 and 157
	 *  @throws IllegalArgumentException if the values are outside the limits.
	 */
	public YUV(final int y, int u, int v) {		
		if(y < 0 || y > YMAX)
			throw new IllegalArgumentException("Invalid value for y in YUV, value "+y);
		if(u < UMIN || u > UMAX )
			throw new IllegalArgumentException("Invalid value for u in YUV, value "+u);
		if(v < VMIN || v > VMAX )
			throw new IllegalArgumentException("Invalid value for v in YUV, value "+v);
		this.y = y;
		this.u = u;
		this.v = v;
	}
	
	/**
	 * Create a new instance of the colorspace with uneditable values.
	 * @param y the luminance - a value between 0 and  255
	 * @param u cyan-red-balance - a value between -111 and 111
	 * @param v yellow-blue-balance - a value between -157 and 15s7
	 *  @throws IllegalArgumentException if the values are outside the limits.
	 */
	public YUV(final String yS, final String uS, final String vS) {
		final int y = Integer.parseInt(yS );
		int u = Integer.parseInt(uS );
		int v = Integer.parseInt(vS );
		
				
		
		if(y < 0 || y > YMAX)
			throw new IllegalArgumentException("Invalid value for y in YUV, value "+y);
		if(u < UMIN || u > UMAX )
			throw new IllegalArgumentException("Invalid value for u in YUV, value "+u);
		if(v < VMIN || v > VMAX )
			throw new IllegalArgumentException("Invalid value for v in YUV, value "+v);
		this.y = y;
		this.u = u;
		this.v = v;
	}
	/** 
	 * Get the luminance Y
	 * @return an integer between 0 and 255
	 */
	public int getY() {
		return y;
	}
	
	/** 
	 * Get the cyan-red-balance U
	 * @return an integer between -111 and 111
	 */
	public int getU() {
		return u;
	}
	
	/** 
	 * Get the yellow-blue-balance V
	 * @return an integer between -157 and 157
	 */
	public int getV() {
		return v;
	}
	
	/**
	 * Convert values into a new RGB instance and return it.
	 * @return an RGB object with the converted values.
	 */
	public RGB returnRGB() {
		final float bf = y + u / 0.493f;
		final float rf = y + v/0.877f;
		final float gf = y - 0.39466f * u - 0.5806f * v;
		
		final int r = Math.round(rf );
		final int g = Math.round(gf);
		final int b = Math.round(bf);
		
		final RGB rgb = new RGB(r, g, b);
		return rgb;
	}
	
	/**
	 * Show YUV - representation as String.
	 * @return a String with all YUV components Y (luminance) and U and V (chromas). 
	 */
	public String toString() {
		final String rep = "YUV\n"+
				"\tY:"+y+"\n"+
				"\tU:"+u+"\n"+
				"\tV:"+v+"\n\n";
		return rep;
	}

}
