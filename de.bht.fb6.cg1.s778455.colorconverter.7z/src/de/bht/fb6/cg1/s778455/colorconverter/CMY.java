package de.bht.fb6.cg1.s778455.colorconverter;

/**
 * This class modelles RGB-color and offers methods to convert it to the CMY
 * color format.
 * @author Sascha Feldmann
 */
public class CMY {
	/**
	 * minimum allowed value for all components.
	 */
	public static final int MIN = 0;
	/**
	 * maxmimum allowed value for all components.
	 */
	public static final int MAX = 255;
	/**
	 * cyan component - a value between MIN and MAX
	 */
	private final int cyan;
	/**
	 * magenta component - a value between MIN and MAX
	 */
	private final int magenta;
	/**
	 * yellow component - a value between MIN and MAX
	 */
	private final int yellow;

	/**
	 * Create an uneditable new CMY color object.
	 * 
	 * @param cyan
	 *            the cyan component of the color, a value between 0 and 255.
	 * @param magenta
	 *            the magenta component of the color, a value between 0 and 255.
	 * @param yellow
	 *            the yellow component of the color, a value between 0 and 255.
	 *  @throws IllegalArgumentException if the values are outside the limits.
	 */
	public CMY( final int cyan, final int magenta, final int yellow ) {
		// Check limits
		if ( cyan > MAX || cyan < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component cyan in CMY. The value you entered is "
							+ cyan );
		if ( magenta > MAX || magenta < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component magenta in CMY. The value you entered is "
							+ magenta );
		if ( yellow > MAX || yellow < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component yellow in CMY. The value you entered is "
							+ yellow );

		this.cyan = cyan;
		this.magenta = magenta;
		this.yellow = yellow;
	}

	/**
	 * Create an uneditable new CMY color object with String inputs.
	 * 
	 * @param cyan
	 *            the cyan component of the color, a value between 0 and 255.
	 * @param magenta
	 *            the magenta component of the color, a value between 0 and 255.
	 * @param yellow
	 *            the yellow component of the color, a value between 0 and 255.
	 * @throws IllegalArgumentException if the values are outside the limits.
	 */
	public CMY( final String cyanS, final String magentaS, final String yellowS ) {
		Integer cyan = Integer.parseInt(cyanS );
		Integer magenta = Integer.parseInt(magentaS );
		Integer yellow = Integer.parseInt(yellowS );
		// Check limits
		if ( cyan > MAX || cyan < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component cyan in CMY. The value you entered is "
							+ cyan );
		if ( magenta > MAX || magenta < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component magenta in CMY. The value you entered is "
							+ magenta );
		if ( yellow > MAX || yellow < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component yellow in CMY. The value you entered is "
							+ yellow );

		this.cyan = cyan;
		this.magenta = magenta;
		this.yellow = yellow;
	}

	/**
	 * Get the cyan value.
	 * @return an integer between 0 and 255.
	 */
	public int getCyan() {
		return cyan;
	}

	/**
	 * Get the magenta value.
	 * @return an integer between 0 and 255.
	 */
	public int getMagenta() {
		return magenta;
	}

	/**
	 * Get the yellow value.
	 * @return an integer between 0 and 255.
	 */
	public int getYellow() {
		return yellow;
	}


	/**
	 * Convert the CMY values to RGB.
	 * 
	 * @return an RGB object
	 */
	public RGB returnRGB() {
		final int r = MAX - cyan;
		final int g = MAX - magenta;
		final int b = MAX - yellow;
		final RGB rgb = new RGB(r, g, b );
		return rgb;
	}
	
	/**
	 * Show CMY - representation as String.
	 * @return a String with all CMY components CYAN MAGENTA YELLOW. 
	 */
	public String toString() {
		final String rep = "CMY\n"+
				"\tCyan:"+cyan+"\n"+
				"\tMagenta:"+magenta+"\n"+
				"\tYellow:"+yellow+"\n\n";
		return rep;
	}
}
