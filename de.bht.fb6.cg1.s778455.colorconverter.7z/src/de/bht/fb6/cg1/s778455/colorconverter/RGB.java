package de.bht.fb6.cg1.s778455.colorconverter;
/**
 * This class modelles RGB-color and offers methods to convert it to the CMY
 * color format.
 * 
 * @author Sascha Feldmann
 * 
 */
public class RGB {
	/**
	 * minimum allowed value for all components.
	 */
	public static final int MIN = 0;
	/**
	 * maxmimum allowed value for all components.
	 */
	public static final int MAX = 255;
	/**
	 * red component - a value between MIN and MAX
	 */
	private final int red;
	/**
	 * green component - a value between MIN and MAX
	 */
	private final int green;
	/**
	 * blue component - a value between MIN and MAX
	 */
	private final int blue;

	/**
	 * Create an uneditable new RGB color object.
	 * 
	 * @param red
	 *            the red component of the color, a value between 0 and 255.
	 * @param green
	 *            the green component of the color, a value between 0 and 255.
	 * @param blue
	 *            the blue component of the color, a value between 0 and 255.
	 * @throws IllegalArgumentException if the values are outside the limits.
	 */
	public RGB( final int red, final int green, final int blue ) {
		// Check limits
		if ( red > MAX || red < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component red in RGB. The value you entered is "
							+ red );
		if ( green > MAX || green < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component green in RGB. The value you entered is "
							+ green );
		if ( blue > MAX || blue < MIN )
			throw new IllegalArgumentException(
					"Illegal value for component blue in RGB. The value you entered is "
							+ blue );

		this.red = red;
		this.green = green;
		this.blue = blue;
	}

	/**
	 * Create an uneditable new RGB color object.
	 * 
	 * @param red
	 *            the red component of the color, a value between 0 and 255.
	 * @param green
	 *            the green component of the color, a value between 0 and 255.
	 * @param blue
	 *            the blue component of the color, a value between 0 and 255.
	 * @throws IllegalArgumentException if the values are outside the limits.
	 */
	public RGB( final String redS, final String greenS, final String blueS ) {
		Integer red = Integer.parseInt(redS );
		Integer green = Integer.parseInt(greenS );
		Integer blue = Integer.parseInt(blueS );
		// Check limits
				if ( red > MAX || red < MIN )
					throw new IllegalArgumentException(
							"Illegal value for component red in RGB. The value you entered is "
									+ red );
				if ( green > MAX || green < MIN )
					throw new IllegalArgumentException(
							"Illegal value for component green in RGB. The value you entered is "
									+ green );
				if ( blue > MAX || blue < MIN )
					throw new IllegalArgumentException(
							"Illegal value for component blue in RGB. The value you entered is "
									+ blue );

				this.red = red;
				this.green = green;
				this.blue = blue;
	}

	/**
	 * Get the red value.
	 * @return an integer between 0 and 255.
	 */
	public int getRed() {
		return red;
	}

	/**
	 * Get the green value.
	 * @return an integer between 0 and 255.
	 */
	public int getGreen() {
		return green;
	}

	/**
	 * Get the blue value.
	 * @return an integer between 0 and 255.
	 */
	public int getBlue() {
		return blue;
	}

	/**
	 * Convert the RGB values to CMY.
	 * @return an CMY object
	 */
	public CMY returnCMY() {
		int c = MAX - red;
		int m = MAX - green;
		int y = MAX - blue;
		CMY cmy = new CMY(c, m, y );
		return cmy;
	}
	
	/**
	 * Convert the RGB values into a new YUV instance
	 * @return the YUV instance
	 */
	public YUV returnYUV() {
		final float yf = 0.299f*red + 0.587f * green + 0.114f * blue;
		final float uf = (blue - yf)*0.493f;
		final float vf = (red - yf)*0.877f;
		
		final int y = Math.round(yf);
		final int u = Math.round(uf);
		final int v = Math.round(vf);
		
		final YUV yuv = new YUV(y, u, v );
	    		
		return yuv;
	}
	
	/**
	 * Show RGB - representation as String.
	 * @return a String with all RGB components RED GREEN BLUE. 
	 */
	public String toString() {
		final String rep = "RGB\n"+
				"\tRed:"+red+"\n"+
				"\tGreen:"+green+"\n"+
				"\tBlue:"+blue+"\n\n";
		return rep;
	}

}
